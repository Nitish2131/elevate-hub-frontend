const BASE_URL = process.env.REACT_APP_BASE_URL ;
const RAZORPAY_KEY_ID = process.env.REACT_APP_RAZORPAY_KEY_ID;
export { BASE_URL, RAZORPAY_KEY_ID };
console.log(BASE_URL);
