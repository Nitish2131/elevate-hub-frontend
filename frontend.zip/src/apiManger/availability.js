import AxiosInstances from ".";

// 🔹 Create Mentor Availability
const createAvailability = async (availabilityData) => {
  return await AxiosInstances.post("/availability", availabilityData);
};

// 🔹 Get Mentor Availability
const getMentorAvailability = async (mentorId, duration) => {
  return await AxiosInstances.get(`/availability/${mentorId}?durationInMinutes=${duration}`);
};

export default { createAvailability, getMentorAvailability };
